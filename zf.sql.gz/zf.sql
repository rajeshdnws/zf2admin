-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 12, 2014 at 04:05 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zf`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE IF NOT EXISTS `album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artist` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `artist`, `title`) VALUES
(10, 'Yes this is album', 'What ?'),
(2, 'Adele', 'tyfytgu'),
(6, 'dasds', 'dasd'),
(7, 'sdfsdf', 'fsdf'),
(8, 'ythrbndfh', 'hgfhdfhdfh'),
(9, 'gsrfsdf', 'fsdgfdgsdg'),
(11, 'dsfs', 'adsfasf');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE IF NOT EXISTS `application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(222) NOT NULL,
  `lname` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `application`
--


-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `state_id` int(10) DEFAULT NULL,
  `city_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `state_id` (`state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `state_id`, `city_name`) VALUES
(1, 2, 'Ajmer'),
(2, 2, 'Alwar'),
(3, 2, 'Jhunjhunu'),
(4, 2, 'Hanumangarh'),
(5, 2, 'Sikar'),
(6, 2, 'Churu'),
(7, 2, 'Ganaganagar'),
(8, 7, 'Rohtak'),
(9, 7, 'Bhiwani');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`) VALUES
(1, 'India'),
(2, 'USA'),
(3, 'Brazil');

-- --------------------------------------------------------

--
-- Table structure for table `keys_status`
--

CREATE TABLE IF NOT EXISTS `keys_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(42) NOT NULL,
  `lname` varchar(44) NOT NULL,
  `keys_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `keys_status`
--

INSERT INTO `keys_status` (`id`, `fname`, `lname`, `keys_status`) VALUES
(4, 'er', 'ewrw', 3),
(5, 'rewr', 'werfwe', 3),
(7, 'er', 'ewsDSDrw', 5),
(8, 'rewADFDFr', 'werfwe', 7);

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `metatitle` tinytext NOT NULL,
  `metakey` tinytext NOT NULL,
  `metadesc` tinytext NOT NULL,
  `create_at` datetime NOT NULL,
  `aliase` text NOT NULL,
  `update_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `title`, `content`, `status`, `metatitle`, `metakey`, `metadesc`, `create_at`, `aliase`, `update_at`) VALUES
(1, 'about us', '<div class="description">\r\n<p>This sample shows how to create and destroy CKEditor instances on the fly. After the removal of CKEditor the content created inside the editing area will be displayed in a <code>&lt;div&gt;</code> element.</p>\r\n\r\n<p>For details of how to create this setup check the source code of this sample page for JavaScript code responsible for the creation and destruction of a CKEditor instance.</p>\r\n</div>\r\n', 1, 'This sample shows how to create and destroy', 'This sample shows how to create and destroy', 'This sample shows how to create and destroy', '2014-10-05 01:49:36', 'about-us', '2014-10-05 01:49:36'),
(2, 'Our Service', '<p>Last Year ITR taxed Amount (If you Paid tax)</p>\r\n\r\n<p>This is basically used for the CA to make your actual tax for this year and the last year&rsquo;s amount will actually give him an idea that what was your last year taxed amount so that the CA can fill a little more this time.</p>\r\n', 1, 'taxed amount so that the CA can fill a little more this time.', 'taxed amount so that the CA can fill a little more this time.', 'taxed amount so that the CA can fill a little more this time.', '2014-10-05 11:07:49', 'service', '2014-10-05 11:07:49'),
(3, 'sfgsg', '<p>gdhfgh</p>\r\n', 0, '', '', '', '2014-10-05 12:42:11', 'fgdfgfd', '2014-10-05 12:42:11');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `city` varchar(222) NOT NULL,
  `address` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `image` varchar(222) NOT NULL,
  `adde_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `userid`, `name`, `email`, `city`, `address`, `phone`, `image`, `adde_date`) VALUES
(1, 1, 'rajesh chaudhary', 'rajeshdnw@gmail.com', 'delhi', '', '', '', '2014-09-28 15:03:41');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `id` char(32) NOT NULL DEFAULT '',
  `name` char(32) NOT NULL DEFAULT '',
  `modified` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `name`, `modified`, `lifetime`, `data`) VALUES
('a8uil4i9tufm91dcbs6onqgb51', 'my_storage_namespace', 1412317063, 1440, '{"id":"1","username":"admin","ip_address":"127.0.0.1","user_agent":"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko\\/20100101 Firefox\\/32.0"}'),
('aagspkci3fas36cftparnajrg2', 'my_storage_namespace', 1412370564, 1440, '{"id":"1","username":"admin","ip_address":"127.0.0.1","user_agent":"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko\\/20100101 Firefox\\/32.0"}'),
('d8g2bhl8tuscclos601venqmr1', 'my_storage_namespace', 1412357004, 1440, '{"id":"1","username":"admin","ip_address":"127.0.0.1","user_agent":"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko\\/20100101 Firefox\\/32.0"}'),
('kfj4h5qb64merpdp2tpt4829c6', 'my_storage_namespace', 1412424546, 1440, '{"id":"1","username":"system","ip_address":"127.0.0.1","user_agent":"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko\\/20100101 Firefox\\/32.0"}'),
('qhl4a6nsj9uh0aro5guf84d692', 'my_storage_namespace', 1412485990, 1440, '{"id":"1","username":"system","ip_address":"127.0.0.1","user_agent":"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko\\/20100101 Firefox\\/32.0"}'),
('s77s9eb6vh2fvmuju3n6njpb51', 'my_storage_namespace', 1412440624, 1440, '{"id":"1","username":"system","ip_address":"127.0.0.1","user_agent":"Mozilla\\/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko\\/20100101 Firefox\\/32.0"}');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `country_id` int(10) DEFAULT NULL,
  `state_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `country_id`, `state_name`) VALUES
(1, 1, 'Aasam'),
(2, 1, 'Rajasthan'),
(3, 1, 'Bihar'),
(4, 1, 'UP'),
(5, 1, 'MP'),
(6, 1, 'Goa'),
(7, 1, 'Haryana'),
(8, 1, 'Punjab'),
(9, 1, 'Maharastra');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `display_name` varchar(50) DEFAULT NULL,
  `password` varchar(128) NOT NULL,
  `state` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `email`, `display_name`, `password`, `state`) VALUES
(1, NULL, 'rajeshdnw@gmail.com', NULL, '$2y$14$PsLprw2.7gK2XejKiQkzyedEPCvpN32Ts4R9XBb0PI3KMDEkxmnPG', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `fname` varchar(222) DEFAULT NULL,
  `lname` varchar(222) NOT NULL,
  `retrieve_password_key` varchar(222) DEFAULT NULL,
  `retrieve_updated_at` varchar(222) DEFAULT NULL,
  `email` varchar(222) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `country` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `updated_at`, `created_at`, `fname`, `lname`, `retrieve_password_key`, `retrieve_updated_at`, `email`, `active`, `country`, `state`, `city`) VALUES
(1, 'system', 'e10adc3949ba59abbe56e057f20f883e', '2014-10-04 16:39:57', '0000-00-00 00:00:00', 'kumar', 'chaudhary', '', '', 'rajeshdnws@gmail.com', 1, 0, 0, 0),
(2, 'admins', 'e10adc3949ba59abbe56e057f20f883e', '2014-10-05 15:49:47', '2014-10-05 15:49:47', 'test', 'test', NULL, NULL, 'admain@gmail.com', 1, 1, 2, 2),
(3, 'adminaa', 'e10adc3949ba59abbe56e057f20f883e', '2014-10-05 15:50:35', '2014-10-05 15:50:35', 'test', 'rajesh', NULL, NULL, 'adamin@gmail.com', 1, 1, 2, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `states`
--
ALTER TABLE `states`
  ADD CONSTRAINT `states_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`);
